/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_objetos_aula2;

/**
 *
 * @author contr
 */
public class ex13_animal {
   
    private String nome;
    private String especie;

    
    public ex13_animal(String nome, String especie) {
        this.nome = nome;
        this.especie = especie;
    }

    
    public String getNome() {
        return nome;
    }

    public String getEspecie() {
        return especie;
    }
}

