/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_objetos_aula2;

/**
 *
 * @author contr
 */
public class ex10_data_main {
    
    
    public static void main(String[] args) {
        ex10_data data = new ex10_data(5, 7, 2025);

        System.out.println("Data formatada: " + data.formatarData());
    }


    
}
