/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java_objetos_aula2;

/**
 *
 * @author contr
 */
public class ex19_pessoatostring_main {
    
    
    public static void main(String[] args) {
        ex19_pessoatostring pessoa1 = new ex19_pessoatostring("Lucas", 28);
        ex19_pessoatostring pessoa2 = new ex19_pessoatostring("Fernanda", 34);

        System.out.println(pessoa1); 
        System.out.println(pessoa2);
    }


    
}
